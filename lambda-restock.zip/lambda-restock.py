def lambda_handler(event, context):
    print("Hello World")

# This part is just for local testing, if needed
if __name__ == "__main__":
    lambda_handler(None, None)
